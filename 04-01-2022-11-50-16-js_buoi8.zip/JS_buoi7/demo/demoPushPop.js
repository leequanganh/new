var monAnArr = ["cơm chiên", "hủ tiếu", "bún bò"];
// =>  thực đơn của nhà hàng
monAnArr.push("bò sốt hào");

console.log(monAnArr);

// lastMeal = monAnArr[monAnArr.length - 1];
var lastMeal = monAnArr.pop();
console.log(lastMeal);
console.log(monAnArr);
