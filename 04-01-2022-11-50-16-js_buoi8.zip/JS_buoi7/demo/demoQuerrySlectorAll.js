var pTagList = document.querySelectorAll(".title");
console.log(pTagList);
