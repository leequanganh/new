var colorArray = new Array("red", "green", "blue", "black");

// console.log(colorArray);

var ageArr = [18, 20, 23, 2, 2, 2, 44, 4, 44];

let firstIndexValue = ageArr[0];

// console.log(firstIndexValue);

let lastIndex = ageArr.length;
// console.log(lastIndex);
// console.log(ageArr[lastIndex - 1]);

var dogNameArr = ["Nâu", "Lu", "Milo", "Mực", "Ki"];
// console.log(dogNameArr[3]);
// start 0 ; end 3; length 4
// lastIndex=4
// length=5   =>  dogNameArr[5] => không  có giá trị
// in ra tất cả tên của các chú cho
// console.log(dogNameArr[0]);
// console.log(dogNameArr[1]);
// console.log(dogNameArr[2]);
// console.log(dogNameArr[3]);

for (let i = 0; i < dogNameArr.length; i++) {
  //   console.log(dogNameArr[i]);
}

dogNameArr.forEach(function (itemm) {
  console.log(itemm);
});

// let callBack = function (item, i) {
//   console.log(item, i);
// };
// dogNameArr.forEach(callBack);
