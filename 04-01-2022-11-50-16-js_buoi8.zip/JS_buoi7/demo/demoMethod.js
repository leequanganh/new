var colorArr = ["red", "blue", "green", "black"];
var redIndex = colorArr.indexOf("red");
var lastRedIndex = colorArr.lastIndexOf("red");
// console.log(redIndex);
// console.log(colorArr.reverse());
// console.log(colorArr.sort());

let string = "hello";
// console.log(string.length);
let demoJoin = colorArr.join(";");
// console.log(demoJoin);

var dogNameArr = ["Nâu", "Lu", "Milo", "Mực", "Ki"];

// map =>  duyệt mảng và ko làm thay đổi  nội  dung gốc
var newDogNameArr = dogNameArr.map(function (item, index) {
  return "con" + " " + item;
});
console.log(newDogNameArr);

var numberArr = [12, 3, 2, 4, 23, 1123, 234, 12];

var soChanArr = numberArr.filter(function (item) {
  return item % 2 == 0;
});
console.log(soChanArr);
var newNumber = numberArr.filter(function (item) {
  return item > 23;
});
console.log(newNumber);
