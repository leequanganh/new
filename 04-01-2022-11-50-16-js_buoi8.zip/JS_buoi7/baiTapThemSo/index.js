var inputEl = document.getElementById("txtInput");
var numberArr = [];

function hienThiKetQua(tongSoChan, countSoAm) {
  document.getElementById("result1").innerText = tongSoChan;
  document.getElementById("result2").innerText = countSoAm;
}

function themSo() {
  var value = inputEl.value.trim() * 1;

  var tongSoChan = 0;
  var countSoAm = 0;
  numberArr.push(value);
  inputEl.value = "";

  for (let i = 0; i < numberArr.length; i++) {
    var currentValue = numberArr[i];
    if (currentValue % 2 == 0) {
      tongSoChan += currentValue;
    }

    if (currentValue < 0) {
      countSoAm++;
    }
  }
  hienThiKetQua(tongSoChan, countSoAm);
}
