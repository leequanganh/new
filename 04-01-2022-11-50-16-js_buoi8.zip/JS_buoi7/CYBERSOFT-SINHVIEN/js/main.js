scoreArr = document.querySelectorAll(".td-scores");

trTagSinhVien = document.querySelectorAll("#tableSinhVien tbody tr");

var maxTrSinhVienTag = trTagSinhVien[0];
var maxCurrentScore = maxTrSinhVienTag.querySelectorAll("td")[3].innerText;
console.log("maxCurrentScore", maxCurrentScore);
for (let index = 0; index < trTagSinhVien.length; index++) {
  var trTag = trTagSinhVien[index];
  var tdTagList = trTag.querySelectorAll("td");
  var currentScore = tdTagList[3].innerText * 1;
  if (currentScore > maxCurrentScore) {
    maxCurrentScore = currentScore;
    maxTrSinhVienTag = trTag;
  }
}
var maxTdList = maxTrSinhVienTag.querySelectorAll("td");
